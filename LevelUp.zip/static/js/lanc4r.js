
var img_flag = true;	// 控制图片进行随机变换的标志
var num_circle = 0;			// 接受 setInterval 的值
//var click_num = 0;			// 定义点击次数!

function $(id){
	return document.getElementById(id);
}


// 获取生存时间
function gettime(){
	var time = new Date();
	var year = time.getFullYear();
	var month = time.getMonth()+1;
	var day = time.getDate();
	var days;

	// 就一个计算时间而已.....  基础时间是 2017.2.16
	if (month < 2){
		if (day < 16){
			days = (year - 2017) * 365 + (2 - month) * 30 + (16 - day);
		}else{
			days = (year - 2017) * 365 + (2 - month) * 30 + (day - 16);
		}
	}else{
		days = (year - 2017) * 365 + (month - 2) * 30 + (day - 16);
	}
	return days;
}



// 信息框的 淡入 和 淡出
function show_msg(elementID){
	var img = document.getElementById(elementID);
	var img_opa = img.style.opacity;

	if (img.movement) {
		clearTimeout(img.movement);
	}

	if (img_opa < 0.2){
		var speed = 0.03;
	}else{
		var speed = 0.02;
	}

	if (img_opa >= 1) {
		return true;
	}

	img.style.opacity = parseFloat(img_opa)+speed;

	var repeat = "show_msg('"+elementID+"')";
	img.movement = setTimeout(repeat,18);
}

function hid_msg(elementID){
	//alert(1);
	var img = document.getElementById(elementID);
	var img_opa = img.style.opacity;

	if (img.movement) {
		clearTimeout(img.movement);
	}

	if (img_opa > 0.8){
		var speed = 0.03;
	}else{
		var speed = 0.02;
	}

	if (img_opa <= 0) {
		return true;
	}

	img.style.opacity = parseFloat(img_opa)-speed;

	var repeat = "hid_msg('"+elementID+"')";
	img.movement = setTimeout(repeat,28);
}

function hid_all(){
	var msg = $('msg');
	var img = $('bar');
	var tw = $('tw');
	var scsj = $('scsj');
	var lt = $('lt');
	var gb = $('gb');
	hid_msg('msg');
	hid_msg('bar');
	hid_msg('tw');
	hid_msg('scsj');
	hid_msg('lt');
	hid_msg('gb');
	//box.style.visibility = "hidden";
}

function close_all(){
	//$('box').style.visibility = "hidden";
	$('yc').style.visibility = "visible";
	$("box").style.display = "none";
}

function open_all(){
	//$('box').style.visibility = "visible";
	$('yc').style.visibility = "hidden";
	$("box").style.display = "block";
	var img = $('bar');
	var tw = $('tw');
	var scsj = $('scsj');
	var lt = $('lt');
	var gb = $('gb');
	show_msg('bar');
	show_msg('tw');
	show_msg('scsj');
	show_msg('lt');
	show_msg('gb');
}



// 图片随机循环
function img_random(){
	if (!img_flag){
		clearInterval(num_circle);
	}else{
		var bar = $('bar');
		var imgs = Array("33draw", "33love", "33sleep", "33hello", "33stand");
		var num = Math.round(Math.random()*4);
		var img = "/static/images/" + imgs[num] + ".gif";
		bar.style.backgroundImage = "url('" + img +"')";
	}
}
//控制循环
function ct_circle(){
	
	img_flag = true;
	//click_num = click_num - 1;
	//if (click_num >= 1){
	//	click_num = click_num - 1;
	//}
	clearInterval(num_circle);
	num_circle = setInterval("img_random()", 3500);

	/*
	if (img_flag){
		
	}*/
}
// 10 秒后设置 flag 的函数!
//function init_flag(){
//	img_flag = true;
//}



// 恢复默认状态
function init(){
	var msg = $('msg');
	var img = $('bar');
	//var tw = $('tw');
	//var scsj = $('scsj');
	//var lt = $('lt');
	//msg.style.visibility = "hidden";
	hid_msg('msg');
	//msg.style.visibility = "hidden";
	img.style.backgroundImage = "url('/static/images/33stand.gif')";


	// 因为 Bug 问题，所以占时关闭 执行动作后的 自动随机切换图片功能！！！！
	// 我是真不知道该怎么写这段代码啊啊啊啊啊啊啊啊啊啊啊！！！！！
	setTimeout("ct_circle()", 10000);


	// 判断是否只是点击了一次，如果大于一次就不掉用！
	//if (click_num < 2){
	//	setTimeout("ct_circle()", 10000);
	//}

	//

	/*
	if (img_flag){
		if (flag){
		setTimeout("ct_circle()", 1);
	}
	}*/
	
	//tw.style.visibility = "visible";
	//scsj.style.visibility = "visible";
	//lt.style.visibility = "visible";
}



// 所有的操作
function action(obj){
	var box = $('box');
	var msg = $('msg');
	var img = $('bar');
	var tw = $('tw');
	var scsj = $('scsj');
	var lt = $('lt');
	var gb = $('gb');

	switch(obj.id){
		case 'tw':
			clearInterval(num_circle);
			msg.innerHTML = "快去戳他邮箱骚扰他~";
			msg.style.visibility = "visible";
			img.style.backgroundImage = "url('/static/images/33draw.gif')";
			show_msg('msg');
			img_flag = false;
			//click_num++;
			//clearInterval(num_circle);
			/*
			tw.style.visibility = "hidden";
			scsj.style.visibility = "hidden";
			lt.style.visibility = "hidden";*/
			setTimeout("init()", 2700);
			break;
		case 'scsj':
			clearInterval(num_circle);
			msg.innerHTML = "我已经诞生 " + gettime() + " 天啦...";
			msg.style.visibility = "visible";
			img.style.backgroundImage = "url('/static/images/33love.gif')";
			show_msg('msg');
			img_flag = false;
			//click_num++;
			//clearInterval(num_circle);
			/*
			tw.style.visibility = "hidden";
			scsj.style.visibility = "hidden";
			lt.style.visibility = "hidden";*/
			setTimeout("init()", 2700);
			break;
		case 'lt':
			clearInterval(num_circle);
			msg.innerHTML = "空尼七哇.....";
			msg.style.visibility = "visible";
			img.style.backgroundImage = "url('/static/images/33sleep.gif')";
			show_msg('msg');
			img_flag = false;
			//click_num++;
			//clearInterval(num_circle);
			/*
			tw.style.visibility = "hidden";
			scsj.style.visibility = "hidden";
			lt.style.visibility = "hidden";*/
			setTimeout("init()", 2700);
			break;
		case 'gb':
			//hid_all();
			//img_flag = false;
			//click_num++;
			//clearInterval(num_circle);
			img_flag = false;
			clearInterval(num_circle);
			msg.innerHTML = "记得再叫我粗来哦.....";
			msg.style.visibility = "visible";
			img.style.backgroundImage = "url('/static/images/33draw.gif')";
			show_msg('msg');
			setTimeout("hid_all()",2000);
			setTimeout("close_all()",4000);
			break;
		//case 'kq':
		//	img_flag = true;
		//	open_all();
		//	break;
		case 'yc':
			//alert("1");
			img_flag = true;
			msg.innerHTML = "我回来啦~";
			msg.style.visibility = "visible";
			img.style.backgroundImage = "url('/static/images/33love.gif')";
			open_all();
			show_msg('msg');
			setTimeout("init()", 2700);
			break;
		default:
			break;
	}
}




// 菜单栏的 弹出 和 隐藏
/*function hidden_menu(){
	$('tw').style.visibility = "hidden";
	$('scsj').style.visibility = "hidden";
	$('lt').style.visibility = "hidden";
}*/

function show_menu(){
	$('tw').style.visibility = "visible";
	$('scsj').style.visibility = "visible";
	$('lt').style.visibility = "visible";
	$('gb').style.visibility = "visible";
	//setTimeout("hidden_menu()", 20000);
	show_msg('tw');
	show_msg('scsj');
	show_msg('lt');
	show_msg('gb');
}


// 刚启动进行初始化
function start(){
	setTimeout("ct_circle()", 10000);
}

start();

