
function $(id){
	return document.getElementById(id);
}

function changeMsgColorBefore(obj){
	//var msg = $(name);
	//alert(obj.id);
	/*
	var msg_a = $(obj.id);
	var msg = msg_a.parentNode;
	msg.style.backgroundColor = "#98C1D9";
	msg_a.style.color = "white";*/
	var msg_a = $(obj.id);
	msg_a.style.color = "red";

	// 判断是否存在子节点  var boolean = node.hasChildNodes();  firstChild 表示 取得第一个元素

	//var child = msg.firstChild;
	//child.style.color = "white";


	//alert(childs.style.color);
	//alert(msg.style.backgroundColor);
}

function changeMsgColorBefore2(obj){
	//var msg = $(name);
	//alert(obj.id);
	/*
	var msg_a = $(obj.id);
	var msg = msg_a.parentNode;
	msg.style.backgroundColor = "#98C1D9";
	msg_a.style.color = "white";*/
	var msg_a = $(obj.id);
	msg_a.style.color = "gray";

	// 判断是否存在子节点  var boolean = node.hasChildNodes();  firstChild 表示 取得第一个元素

	//var child = msg.firstChild;
	//child.style.color = "white";


	//alert(childs.style.color);
	//alert(msg.style.backgroundColor);
}

function changeMsgColorAfter(obj){
	/*
	var msg_a = $(obj.id);
	var msg = msg_a.parentNode;
	msg.style.backgroundColor = "white";
	msg_a.style.color = "#98C1D9";*/

	var msg_a = $(obj.id);
	msg_a.style.color = "black";
}



/*
function test1(){
	alert(1);
}
*/


//alert(1);