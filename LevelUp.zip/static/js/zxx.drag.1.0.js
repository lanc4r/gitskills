// 隐藏所有元素！
/*
function $(id){
	return document.getElementById(id);
}

function hid_msg(elementID){
	//alert(1);
	var img = document.getElementById(elementID);
	var img_opa = img.style.opacity;

	if (img.movement) {
		clearTimeout(img.movement);
	}

	if (img_opa > 0.8){
		var speed = 0.03;
	}else{
		var speed = 0.02;
	}

	if (img_opa <= 0) {
		return true;
	}

	img.style.opacity = parseFloat(img_opa)-speed;

	var repeat = "hid_msg('"+elementID+"')";
	img.movement = setTimeout(repeat,28);
}




// ********  33 娘贴边隐藏的代码部分(未完成！)
function hid_all(){
	var msg = $('msg');
	var img = $('bar');
	var tw = $('tw');
	var scsj = $('scsj');
	var lt = $('lt');
	var gb = $('gb');
	hid_msg('msg');
	hid_msg('bar');
	hid_msg('tw');
	hid_msg('scsj');
	hid_msg('lt');
	hid_msg('gb');
	//box.style.visibility = "hidden";
}

function close_all(){
	$('box').style.visibility = "hidden";
}

function display_none(){
	var box = $("box");
	box.style.display = "none";
}

function hid_msg(elementID){
	//alert(1);
	var img = document.getElementById(elementID);
	var img_opa = img.style.opacity;

	if (img.movement) {
		clearTimeout(img.movement);
	}

	if (img_opa > 0.8){
		var speed = 0.03;
	}else{
		var speed = 0.02;
	}

	if (img_opa <= 0) {
		return true;
	}

	img.style.opacity = parseFloat(img_opa)-speed;

	var repeat = "hid_msg('"+elementID+"')";
	img.movement = setTimeout(repeat,28);
}

function hid_all2(){
	var msg = $('msg');
	var img = $('bar');
	var tw = $('tw');
	var scsj = $('scsj');
	var lt = $('lt');
	var gb = $('gb');
	hid_msg('msg');
	hid_msg('bar');
	hid_msg('tw');
	hid_msg('scsj');
	hid_msg('lt');
	hid_msg('gb');
	alert("1");
	//box.style.visibility = "hidden";
	//setTimeout("display_none", 1500);
}

// 进行 33娘 边界判断的一个函数
function judge_border(){

	var box = document.getElementById("box");

	// 获取 box 元素的 左上角的点
	var boxX = parseInt(box.style.left);
	var boxY = parseInt(box.style.top);

	//alert(boxX + box.offsetWidth);
	//alert(window.innerWidth);


	// 当超出边界之后，不让其直接消失，让33 回到初始位置再消失！
	if ( ((boxX + box.offsetWidth) >= window.innerWidth - 25) || (boxX < 0) ){
		//alert("横轴到达边界!");
		hid_all2();
		//box.style.left = "1250px";
		//box.style.top = "500px";
		//box.style.display = "none";
		//setTimeout("display_none", 1500);
	}

	if ( ((boxY + box.offsetHeight) >= window.innerHeight) || (boxY < 0) ){
		//alert("纵轴达到边界！");
		hid_all2();
		//box.style.display = "none";
		//setTimeout("display_none", 1500);
	}	

	//alert(boxX + " || " + boxY);

	//var box = $('box');
	//alert(box.offsetHeight);
}*/

var params = {
	left: 0,
	top: 0,
	currentX: 0,
	currentY: 0,
	flag: false
};
//获取相关CSS属性
//var getCss = function(o,key){
//	return o.currentStyle? o.currentStyle[key] : document.defaultView.getComputedStyle(o,false)[key]; 	
//};

//拖拽的实现
var startDrag = function(bar, target, callback){
	/*if(getCss(target, "left") !== "auto"){
		params.left = getCss(target, "left");
	}
	if(getCss(target, "top") !== "auto"){
		params.top = getCss(target, "top");
	}*/
	params.left = target.style.left;
	params.top = target.style.top;
	//o是移动对象
	bar.onmousedown = function(event){
		params.flag = true;
		if(!event){
			event = window.event;
			//防止IE文字选中
			bar.onselectstart = function(){
				return false;
			}  
		}
		var e = event;
		params.currentX = e.clientX;
		params.currentY = e.clientY;
	};
	document.onmouseup = function(){
		params.flag = false;

		params.left = target.style.left;
		params.top = target.style.top;
		/*
		if(getCss(target, "left") !== "auto"){
			params.left = getCss(target, "left");
		}
		if(getCss(target, "top") !== "auto"){
			params.top = getCss(target, "top");
		}*/
		//judge_border();
		//judge_border();
	};
	document.onmousemove = function(event){
		var e = event ? event: window.event;
		if(params.flag){
			var nowX = e.clientX, nowY = e.clientY;
			var disX = nowX - params.currentX, disY = nowY - params.currentY;
			target.style.left = parseInt(params.left) + disX + "px";
			target.style.top = parseInt(params.top) + disY + "px";
		}
		
		if (typeof callback == "function") {
			callback(parseInt(params.left) + disX, parseInt(params.top) + disY);
		}
	}	
};



