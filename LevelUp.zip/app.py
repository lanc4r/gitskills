#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging; logging.basicConfig(level=logging.INFO)
import asyncio, os
from jinja2 import Environment, FileSystemLoader
from aiohttp import web
from ShowMain import ShowMain
from DownloadInfo import LoginError

# 因为使用的是 jinja2 模板，我们需要使用前初始化一下下
def init_jinja2(app):
	logging.info('init jinja2...')
	# 设置一些初始化参数(比如 自动转义、块开始、结束标志、以及自动重载什么的...)
	options = dict(
		autoescape = True,
		block_start_string = '{%',
		block_end_string = '%}',
		variable_start_string = '{{',
		variable_end_string = '}}',
		auto_reload = True
	)

	# 拼接模板文件路径
	path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
	logging.info('set jinja2 template path: %s' % path)
	# 加载模板文件，初始化模板
	env = Environment(loader=FileSystemLoader(path), **options)
	app['__templating__'] = env

# 加载静态文件(方便我们访问 css js 文件啦)
def add_static(app):
	path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
	app.router.add_static('/static/', path)
	logging.info('add static %s => %s' % ('/static', path))


# 妈的，这个 aiohttp 需要 middleware，在一个 URL 处理前，或者是 返回前 搞些事情，真麻烦...
async def logger_factory(app, handler):
	async def logger(request):
		logging.info('Request: %s %s' % (request.method, request.path))
		return (await handler(request))
	return logger

# 需要在返回前转换为 Response 对象，不然就会报错哒
# like this AssertionError: Handler <function index at 0x03A9F660> should return response instance, got <class 'dict'> [middlewares []]
# 不解释这么多了，需要自己区了解！
async def response_factory(app, handler):
	async def response(request):
		logging.info('Response handler...')
		#logging.info(handler)

		# 到这里的 handler 就变成了 web.Application 内部的一个处理函数了
		r = await handler(request)
		
		# 返回不同的数据时候，需要做出不同的决定
		
		if isinstance(r, web.StreamResponse):
			return r
		if isinstance(r, bytes):
			resp = web.Response(body=r)
			resp.content_type = 'application/octet-stream'
			return resp
		if isinstance(r, str):
			if r.startswith('redirect:'):
				return web.HTTPFound(r[9:])
			resp = web.Response(body=r.encode('utf-8'))
			resp.content_type = 'text/html;charset=utf-8'
			return resp

		if isinstance(r, dict):
			template = r.get('__template__')
			resp = web.Response(body=app['__templating__'].get_template(template).render(**r).encode('utf-8'))
			resp.content_type = 'text/html;charset=utf-8'
			return resp
		# default:
		resp = web.Response(body=str(r).encode('utf-8'))
		resp.content_type = 'text/plain;charset=utf-8'
		return resp
	return response

def index(request):
	return {
		'__template__': 'home.html'
	}
	
def getinfo(request):
	return {
		'__template__': 'home.html'
	}

def getabout(request):
	return {
		'__template__': 'about.html'
	}

async def getinfo_form(request):
	try:
		# 拿到表单传入的数据
		params = await request.post()
		kw = dict(**params)
		stuid = kw.get('stuid', None)
		pwd = kw.get('password', None)
		showMain = ShowMain(stuid, pwd)
		classTB = showMain.showClassInfo()
		vals = showMain.showGrandInfo()
		return {
			'__template__': 'result.html',
			'avgGrand': ('%.3f' % vals[0]),
			'avgWeightGrand': ('%.3f' % vals[1])
		}
		#return render_template('showinfo.html', avgGrand=('%.3f' % vals[0]), avgWeightGrand=('%.3f' % vals[1]))
	except LoginError as e:
		return {
			'__template__': 'home.html',
			'message': 'Stuid Or Pwd Is Wrong!'
		}
		#return render_template('index.html', message='输入错哒，才不关我事咧~ （￣へ￣）')
	#except Exception as e:
		#return '<h3>把作者拖出来打一顿就好了 (╯°口°)╯</h3>'

#@asyncio.coroutine
async def init(loop):
	app = web.Application(loop=loop,  middlewares=[
		logger_factory, response_factory
	])
	init_jinja2(app)
	add_static(app)
	# 注册处理函数
	app.router.add_route('GET', '/', index)
	app.router.add_route('GET', '/getinfo', getinfo)
	app.router.add_route('GET', '/about', getabout)
	app.router.add_route('POST', '/getinfo', getinfo_form)
	srv = await loop.create_server(app.make_handler(), '127.0.0.1', 9000)
	logging.info('server started at http://127.0.0.1:9000...')
	return srv

loop = asyncio.get_event_loop()
loop.run_until_complete(init(loop))
loop.run_forever()