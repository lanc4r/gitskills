#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
	操作 DownloadInfo 、ParseInfo、ShowInfo 
'''

from DownloadInfo import DownloadInfo, LoginError		# 后面换位置
from ParseInfo import ParseInfo

class ShowMain(object):

	def __init__(self, stuid, pwd):
		self._downloadInfo = DownloadInfo(stuid, pwd)
		self._parseInfo = ParseInfo()

	def showClassInfo(self):
		classInfo = self._downloadInfo.GetClassInfo()			# 使用下载器 获得课程的具体
		self._parseInfo.addClassInfo(classInfo)					# 通过解析器 得到相应的课程列表
		#print (self._parseInfo.returnClassInfo())				# 打印出来(后面可以写一个专门用于显示的类)
		return self._parseInfo.returnClassInfo()				# 返回 课表信息

	def showGrandInfo(self):
		grandInfo = self._downloadInfo.GetGrandInfo()			# 使用下载器 获得成绩的具体
		self._parseInfo.addGrandInfo(grandInfo)					# 通过解析器 计算得到相应的成绩
		#print ('Avg Grand Is: %.2f  And Avg Weighted Grand Is: %.2f' % self._parseInfo.returnGrandInfo())	# 打印出来(后面可以写一个专门用于显示的类)
		return self._parseInfo.returnGrandInfo()				# 返回平均数 和 加权平均数

'''
if __name__ == '__main__':
	stuid = input('Input Your Student ID: ')
	pwd = input('Input Your Password: ')

	try:
		showMain = ShowMain(stuid, pwd)
		print ('课表见下： ******************************************')
		showMain.showClassInfo()
		print ('成绩具体信息: ****************************************')
		showMain.showGrandInfo()
	except LoginError as e:
		print ('学号或密码错误 (╯°口°)╯')
'''