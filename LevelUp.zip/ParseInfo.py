#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
	分析来自 DownloadInfo 的信息，得到具体的 课程列表 以及 计算得到 平均值和加权平均值
'''

from bs4 import BeautifulSoup
import re

class ParseInfo(object):

	def __init__(self):
		self._grandList = []					# 成绩
		self._creditList = []					# 学分
		self._classList = []					# 课程
		self._avgGrand = 0						# 平均分
		self._avgWeightedGrand = 0				# 加权平均分

	def addClassInfo(self, content):
		soup = BeautifulSoup(content, 'lxml')
		table = soup.find(attrs={'bgcolor': '#F2EDF8'})
		tr_s = table.find_all('tr')
		
		for tr in tr_s:
			#print (tr.td.p.string)
			temp_list = []
			td_s = tr.find_all(name='td')
			for td in td_s:
				if td.p.find(name='strong'):
					# 判断 是否是空字段，如果是 填入 ####，否则相应的值
					temp_list.append('####') if td.p.get_text().find('nbsp') > -1 else temp_list.append(td.p.get_text())
				else:
					# 同上 判断是否含有 font 标签，如果含有表示此格内容不为空，否则表示为空 添加 #### 即可！
					temp_list.append(re.match(r'([\s\S])(.*)', td.p.get_text()).group(2)) if td.p.find(name='font') else temp_list.append('####')

			self._classList.append(temp_list)

	# 因为直接知道位置，所以我们采用更加简单的方法啦！！
	def addGrandInfo(self, content):
		grands = []
		soup = BeautifulSoup(content, 'lxml')
		tables = soup.find_all(name='table')

		for table in tables:
			# 判断是否是 含有我们需要信息的 table
			if ('bgcolor' in table.attrs and table.attrs['bgcolor'] == '#F2EDF8') or ('border' in table.attrs and table.attrs['border'] == '3'):
				tr_s = table.find_all(name='tr')

				for tr in tr_s:
					#pos_flag = 1					# 设置获取 学分,成绩 的标志位	
					if ('bgcolor' not in tr.attrs) and (len(tr.find_all(name='td')) > 1):			# 我们需要找到 没有 bgcolor 以及 子节点不是 th 的 tr
						td_s = tr.find_all(name='td')
						for index, td in enumerate(td_s):
							if index == 3:
								# 判断是否是智障教务处设置的 .5 学分，如果是将其添加为 0.5(根据下面计算出来的， .5 表示的是 0.5)
								self._creditList.append('0.5') if td.get_text().startswith('.') else self._creditList.append(td.get_text())

							if index == 5:
								# 判断成绩内容里 是否为 四六级成绩，如果是 则删除之前添加的学分，如果不是 再判断是否是 【优秀|良好|一般|合格】
								# 判断的标准为： 优秀=95， 良好=85， 一般=75， 合格=65

								if re.match(r'(\d{2,3}|优秀|良好|一般|合格)', td.get_text()):
									if td.get_text().startswith('优秀'):
										self._grandList.append('95')
									elif td.get_text().startswith('良好'):
										self._grandList.append('85')
									elif td.get_text().startswith('一般'):
										self._grandList.append('75')
									elif td.get_text().startswith('合格'):
										self._grandList.append('65')
									elif int(td.get_text()) < 101:							# 判断是否是六级
										self._grandList.append(td.get_text())
									else:
										self._creditList.pop()								# 否则把之前 四六级 添加的学分 删除掉

								
								#self._grandList.append(td.get_text()) if re.match(r'\d{2,3}', td.get_text()) and int(td.get_text()) < 101 else self._creditList.pop()

		# 将字符串转化为数字
		self._creditList = [float(credit) for credit in self._creditList]
		self._grandList = [int(grand) for grand in self._grandList]

		# 得到平均分
		self._avgGrand = sum(self._grandList) / len(self._grandList)

		# 得到加权平均分
		self._avgWeightedGrand = sum([self._creditList[i] * self._grandList[i] for i in range(len(self._creditList))]) / sum(self._creditList)
		#print ('Avg Grand Is: %.2f  And Avg Weighted Grand Is: %.2f' % (self._avgGrand, self._avgWeightedGrand))


	# 返回课程列表
	def returnClassInfo(self):
		return self._classList

	# 返回 平均分 和 加权平均分
	def returnGrandInfo(self):
		return self._avgGrand, self._avgWeightedGrand


'''
if __name__ == '__main__':
	stuid = input('Input Your Student ID: ')
	pwd = input('Input Your Password: ')

	getInfo = DownloadInfo(stuid, pwd)
	showInfo = ParseInfo()

	class_content = getInfo.GetClassInfo()
	grand_content = getInfo.GetGrandInfo()

	showInfo.addGrandInfo(grand_content)

	#showInfo.printClassInfo(class_content)
	#showInfo.printAvgInfo(grand_content)
	#print (content)
'''

