#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''
	用于下载网页上的 课程信息 和 成绩信息
'''

import requests
import re

class LoginError(Exception):
	pass

class DownloadInfo(object):

	def __init__(self, stuid, pwd):
		self._stuid = stuid
		self._pwd = pwd
		self._cookies = dict()
		self._url_login = 'http://jwgl.lnu.edu.cn/pls/wwwbks/bks_login2.login'
		self._url_classTB = 'http://jwgl.lnu.edu.cn/pls/wwwbks/xk.CourseView'
		self._url_grandTB = 'http://jwgl.lnu.edu.cn/pls/wwwbks/bkscjcx.yxkc'

	def GetClassInfo(self):
		payload = {'stuid': self._stuid, 'pwd': self._pwd}
		index = requests.post(self._url_login, data=payload)
		index.encoding = 'gb2312'
		# 判断学号和密码是否正确
		if index.text.find('错误的学号或密码') > -1:
			# 登陆失败，抛出异常
			raise LoginError()
		self._cookies = dict(ACCOUNT=index.history[0].cookies['ACCOUNT'])				# 获取重定向之前的 设置的 cookie ，并将其构造进入 cookies 参数中，用于获取课表以及成绩
		r = requests.get(self._url_classTB, cookies=self._cookies)						# 获取课表页面的数据
		r.encoding = 'gb2312'
		return r.text

	def GetGrandInfo(self):
		r = requests.get(self._url_grandTB, cookies=self._cookies)
		r.encoding = 'gb2312'
		return r.text

'''
if __name__ == '__main__':

	stuid = input('Input Your Student ID: ')
	pwd = input('Input Your Password: ')
	getInfo = GetInfo(stuid, pwd)
	content = getInfo.GetClassInfo()
'''
	

'''
				if re.match(r'(.*?)(&nbsp;)$', td.p.get_text()):
					print (td.p.get_text())
				else:
					print ('#####')


				if td.p.get_text().find('&nbsp;'):
					print ('#####')
				else:
					print (td.p.get_text())
				#if td.p.string
				#print (td.p.get_text())

		#print (len(tr_s))
		#print (type(table))
'''



	#print (getInfo.GetClassInfo())
	#print ('*******************************************************')
	#print (getInfo.GetGrandInfo())




# 爬辽大成绩
'''
查看已修课程的部分

GET /pls/wwwbks/bkscjcx.yxkc HTTP/1.1
Host: jwgl.lnu.edu.cn
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Referer: http://jwgl.lnu.edu.cn/zhxt_bks/zhxt_bks_left.html
Cookie: ACCOUNT=1414041040920213148
Connection: keep-alive
Upgrade-Insecure-Requests: 1

GET /zhxt_bks/zhxt_bks.html HTTP/1.1
Host: jwgl.lnu.edu.cn
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Referer: http://jwgl.lnu.edu.cn/
Connection: keep-alive
Upgrade-Insecure-Requests: 1
If-Modified-Since: Thu, 06 Jul 2006 16:00:00 GMT
If-None-Match: "2caa2-27a-44ad3380"
Cache-Control: max-age=0


POST /pls/wwwbks/bks_login2.login?jym2005=8591.50409843729 HTTP/1.1
Host: jwgl.lnu.edu.cn
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded
Content-Length: 30
Referer: http://jwgl.lnu.edu.cn/zhxt_bks/zhxt_bks_right.html
Connection: keep-alive
Upgrade-Insecure-Requests: 1

stuid=141404104&pwd=wdst123456


GET /pls/wwwbks/bks_login2.loginmessage HTTP/1.1
Host: jwgl.lnu.edu.cn
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Referer: http://jwgl.lnu.edu.cn/zhxt_bks/zhxt_bks_right.html
Cookie: ACCOUNT=141404104 09/20 20:29:39		141404104 0920204054
Connection: keep-alive
Upgrade-Insecure-Requests: 1


GET /pls/wwwbks/bks_login2.loginmessage HTTP/1.1
Host: jwgl.lnu.edu.cn
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Referer: http://jwgl.lnu.edu.cn/zhxt_bks/zhxt_bks_right.html
Cookie: ACCOUNT=1414041040920210133
Connection: keep-alive
Upgrade-Insecure-Requests: 1



'''

'''
import requests
import re


headers = {
	'Host': 'jwgl.lnu.edu.cn',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
	'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0',
	'Accept-Language': 'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
	'Accept-Encoding': 'gzip, deflate',
	'Content-Type': 'application/x-www-form-urlencoded',
	'Referer': 'http://jwgl.lnu.edu.cn/zhxt_bks/zhxt_bks_right.html'
}


payload = {'stuid': 141404104, 'pwd': 'wdst123456'}

url_kb = 'http://jwgl.lnu.edu.cn/pls/wwwbks/xk.CourseView'

r = requests.post('http://jwgl.lnu.edu.cn/pls/wwwbks/bks_login2.login', data=payload)

print (r.url)

print (r.status_code)
print ('*******************************')
r.encoding = 'gb2312'
print (r.text)
print ('*******************************')

cookie = r.history[0].cookies['ACCOUNT']

cookies = dict(ACCOUNT=cookie)

r2 = requests.get(url_kb, cookies=cookies)
r2.encoding = 'gb2312'
print (r2.text)
'''







# http://jwgl.lnu.edu.cn/pls/wwwbks/bks_login2.login

#r = requests.get('http://jwgl.lnu.edu.cn/zhxt_bks/zhxt_bks.html')
#r.encoding = 'gb2312'

#print (r.encoding)
#print (r.headers)
#print (r.text)


